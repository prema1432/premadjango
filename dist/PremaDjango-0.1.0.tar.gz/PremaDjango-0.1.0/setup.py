from setuptools import setup, find_packages

setup(
    name='PremaDjango',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'Django',  # Add other default libraries here
    ],
)