from setuptools import setup, find_packages

setup(
    name='PremaDjango',
    version='0.1.6.dev0+14579c7',
    use_scm_version=True,
    setup_requires=['setuptools_scm'],
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
)
