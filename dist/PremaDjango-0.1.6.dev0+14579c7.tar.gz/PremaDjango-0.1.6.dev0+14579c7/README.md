# Prema Django

`premadjango` is a Python package that provides default configurations and settings for new Django projects.

## Installation

You can install `premadjango` using pip:

```bash
pip install premadjango
